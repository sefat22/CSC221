public class Main {
    public static void main(String[] args) {
        System.out.println("Hello Test Project");
    }
}


/*

initially:
    git init
    git commit -m 'first message'
    git branch -m main
    git remote..
    git push

incremental updates:
    git add .
    git commit -m 'message'
    git push

 */